package com.qintess.acompanhaCorreio.processamento;

import java.util.ArrayList;
import java.util.List;

import com.qintess.acompanhaCorreio.model.Pedido;

public class ProcessaArquivo {

	// Atributos
	private List<Pedido> lstPedidos;
	
	// Construtor
	public ProcessaArquivo(List<String> lstArquivo) {
		
		lstPedidos = new ArrayList<Pedido>();
		
		lstArquivo.remove(0);
		
		for (String registro : lstArquivo) {
			Pedido pedido = new Pedido(registro);
			lstPedidos.add(pedido);
		}
	}

	// Getter and Setter
	public List<Pedido> getLstPedidos() {
		return lstPedidos;
	}
	public void setLstPedidos(List<Pedido> lstPedidos) {
		this.lstPedidos = lstPedidos;
	}

}
