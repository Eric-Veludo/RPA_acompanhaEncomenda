package com.qintess.acompanhaCorreio.utils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public interface TrabalhaArquivo {
	
	public static List<String> leArquivo(String caminho) throws IOException {
		return Files.readAllLines(Path.of(caminho));
	}
	
	public static boolean escreveArquivo(String caminho, String nomeArquivo, List<String> lstArquivo) throws IOException {
		Files.write(Path.of(caminho + "//" + nomeArquivo + ".csv"), lstArquivo);
		return true;
	}
	
}