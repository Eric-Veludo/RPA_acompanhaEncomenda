package com.qintess.acompanhaCorreio.processamento;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class IniciaProcessamento {

	// Atributos
	protected WebDriver driver;

	
	// Construtor
	protected IniciaProcessamento() {
		System.setProperty("webdriver.chrome.driver", "path_chromedriver");
		driver = new ChromeDriver();
	} 
	
	// Processamento
	protected void openBrowser(String url) {
		driver.get(url);
		driver.manage().window().maximize();
	}

	public void closeBrowser() {
		driver.close();
	}
	
	public void closeDriver() {
		driver.quit();
	}
	
}
