package com.qintess.acompanhaCorreio;

import java.util.ArrayList;
import java.util.List;
import com.qintess.acompanhaCorreio.model.Pedido;
import com.qintess.acompanhaCorreio.processamento.Processa;
import com.qintess.acompanhaCorreio.processamento.ProcessaArquivo;
import com.qintess.acompanhaCorreio.utils.EmailHelper;
import com.qintess.acompanhaCorreio.utils.TrabalhaArquivo;

public class App 
{
	public static void main( String[] args )
	{

		Processa processa = null;
		EmailHelper emailHelper;
		
		String retorno = null;
		String assunto = null;
		String msg = null;
		
		List<String> lstArquivo;
		List<Pedido> lstPedidos;
		
		try {

			lstArquivo = TrabalhaArquivo.leArquivo("path_arquivo_csv");			
			ProcessaArquivo processaArquivo =  new ProcessaArquivo(lstArquivo);
			lstPedidos = processaArquivo.getLstPedidos();
			emailHelper = new EmailHelper();			
			lstArquivo = new ArrayList<String>();
			
			lstArquivo.add("Cod;Nome;Email;Status");
			
			for (Pedido pedido : lstPedidos) {

				processa = new Processa("https://www2.correios.com.br/sistemas/rastreamento/");
				processa.digitarTexto("//textarea[@id='objetos']", pedido.getCodPedido());
				processa.clicar("//input[@id='btnPesq']");
				retorno = processa.getMessage("//table[@class='listEvent sro'][1]/tbody/tr/td[2]");

				if (!retorno.equals(pedido.getStatus())) {
					
					pedido.setStatus(retorno);
			
					if (pedido.getStatus().equals("Objeto entregue ao destinatário")) {
						assunto = "Obaaa! seu pedido chegou!!";
						msg = "Ei sr(a). " + pedido.getNome() + ", soubemos que seu pedido chegou, esperamos que tenha gostado!!"
								+ "\nParabéns pela aquisição"
								+ "\nAvalie o produto em https:\\google.com.br";
					} else {
						assunto = "Eiii, fica de olho, o status do seu pedido foi atualizado!!";
						msg = "Olá sr(a). " + pedido.getNome() + ", o Status do seu pedido foi atualizado"
								+ "\nSegue o status atualizado:"
								+ "\n" + pedido.getStatus();
					}
					
					emailHelper.enviarEmail(pedido.getEmail(), assunto, msg);
				}
				
				lstArquivo.add(pedido.getCodPedido() + ";" + pedido.getNome() + 
								";" + pedido.getEmail() + ";" + pedido.getStatus());
				
				Thread.sleep(3000);
				
				processa.closeBrowser();
				
			}

			TrabalhaArquivo.escreveArquivo("path_arquivo_csv", "nome_do_arquivo", lstArquivo);
				
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			processa.closeDriver();
		}

	}
}
