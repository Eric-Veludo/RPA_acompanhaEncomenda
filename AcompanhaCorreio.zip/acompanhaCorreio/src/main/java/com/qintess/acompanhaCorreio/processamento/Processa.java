package com.qintess.acompanhaCorreio.processamento;

import org.openqa.selenium.By;

public class Processa extends IniciaProcessamento {

	// Construtor
	public Processa(String url) {
		super();
		super.openBrowser(url);
	}

	
	// Processamento
	public void digitarTexto(String elemento, String texto) {
		driver.findElement(By.xpath(elemento)).sendKeys(texto);;
	}


	public void clicar(String elemento) {
		driver.findElement(By.xpath(elemento)).click();
	}


	public String getMessage(String elemento) {
		return driver.findElement(By.xpath(elemento)).getText();
	}
}
