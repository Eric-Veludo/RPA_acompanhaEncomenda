package com.qintess.acompanhaCorreio.model;

public class Pedido {
	
	// Atributos
	private String codPedido;
	private String nome;
	private String email;
	private String status;
	
	// Construtor
	public Pedido(String dados) {
		String[] arr = dados.split(";");
		
		codPedido = arr[0];
		nome = arr[1];
		email = arr[2];
		status = arr[3];
		
	}

	// Getters and Setters
	public String getCodPedido() {
		return codPedido;
	}
	public void setCodPedido(String codPedido) {
		this.codPedido = codPedido;
	}

	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}

	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		 this.status = status;
	}
	
}
