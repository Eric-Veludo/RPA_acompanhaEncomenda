package com.qintess.acompanhaCorreio.utils;

import java.util.Date;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.MimeMessage;

public class EmailHelper {


	// Atributos
	Properties props;
	String username;
	String pass;
	Session session;
	
	public EmailHelper() {

		props = new Properties();
		username = "seu_email";
		pass = "sua_senha";

		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");

		session = Session.getInstance(props, new Authenticator() {

			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, pass);
			}

		});

	}
	
	
	public void enviarEmail(String destinatario, String assunto, String texto) throws MessagingException {
		
		MimeMessage msg = new MimeMessage(session);
		msg.setFrom(username);
		msg.setRecipients(Message.RecipientType.TO, destinatario);
		msg.setSubject(assunto);
		msg.setSentDate(new Date());
		msg.setText(texto);

		Transport.send(msg, username, pass);
		
	}
	

}
